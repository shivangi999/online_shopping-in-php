<body>
<br /><br />
<center><font color="#993399" size="+3" face="Georgia, Times New Roman, Times, serif">Welcome User</font><br/><br>
<font color="#CC3366" size="+3" face="Georgia, Times New Roman, Times, serif">You are in the DevFoo Shop.</font><br/><br>
<font color="#003333" size="+2">You are Successfully logged in!!! </font><br/><br/>
<p style="font-size:22px; font-weight:bold;">We welcome you to Liberal DevFoo Channel
	If you like this code and want the more projects like this and better than this..
	Please give one Like, Follow and Share this Project 
	<br>
	Thank You!!
<br>
<br>
Don't Forget to subscribe our channel
 </p>
</center>

</body>