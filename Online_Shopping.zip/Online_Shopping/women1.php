<html>
<body>
<div><center><h2><font face="Lucida Handwriting" size="+1" color="#00CCFF">WOMEN'S APPAREL</font></h2></center></div>
<div align="center">
<a href="mdress.html"><img src="images/dress.jpg"></a>
<a href="msuits.html"><img src="images/suits.jpg"></a>
<a href="mkurtas.html"><img src="images/kurtas.jpg"></a><br>
<a href="msandals.html"><img src="images/f1.jpg"></a>
<a href="moffice.html"><img src="images/office.jpg"></a>
<a href="mjewel.html"><img src="images/jewel.jpg"></a>

</div>
</body>
</html>
